export interface MobileDeviceData {
    manufacturer: string,
    browser: string,
    os: string
}