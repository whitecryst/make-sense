export enum LineAnchorType {
    START = "START",
    END = "END"
}