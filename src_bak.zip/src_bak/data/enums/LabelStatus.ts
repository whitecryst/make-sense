export enum LabelStatus {
    ACCEPTED = "ACCEPTED",
    REJECTED = "REJECTED",
    UNDECIDED = "UNDECIDED"
}