export enum ContextType {
    EDITOR = "EDITOR",
    LEFT_NAVBAR = "LEFT_NAVBAR",
    RIGHT_NAVBAR = "RIGHT_NAVBAR",
    POPUP = "POPUP",
    DROPDOWN = "DROPDOWN"
}