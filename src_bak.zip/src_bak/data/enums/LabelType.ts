export enum LabelType {
    IMAGE_RECOGNITION = "IMAGE RECOGNITION",
    POINT = "POINT",
    RECT = "RECT",
    POLYGON = "POLYGON",
    LINE = "LINE"
}