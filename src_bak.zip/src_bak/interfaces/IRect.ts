export interface IRect {
    x:number,
    y:number,
    height:number,
    width:number
}