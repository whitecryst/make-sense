import {AnnotationFormatType} from "../data/enums/AnnotationFormatType";

export interface ILabelFormatData {
    type: AnnotationFormatType,
    label: string
}