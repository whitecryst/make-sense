import {IPoint} from "./IPoint";

export interface ILine {
    start: IPoint,
    end: IPoint
}