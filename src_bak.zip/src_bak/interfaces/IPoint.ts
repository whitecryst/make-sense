export interface IPoint {
    x:number,
    y:number
}